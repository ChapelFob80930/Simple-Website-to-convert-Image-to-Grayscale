var image;
var grayscaleimg;
function upload()
{
  var but1=document.getElementById("b1");
  var canvas1=document.getElementById("can1");
  image=new SimpleImage(but1);
  grayscaleimg=new SimpleImage(but1);
  image.drawTo(canvas1);
}

function makeGray()
{
  for(var pixel of grayscaleimg.values())
  {
    var avg= (pixel.getRed()+pixel.getGreen()+pixel.getBlue())/3;
    pixel.setRed(avg);
    pixel.setGreen(avg);
    pixel.setBlue(avg);
  }
  var canvas2=document.getElementById("can2");
  grayscaleimg.drawTo(canvas2);
}

