# Uploading Image And making it grayscale on a Website

A Pen created on CodePen.io. Original URL: [https://codepen.io/ChapelFob80930/pen/poXvpeJ](https://codepen.io/ChapelFob80930/pen/poXvpeJ).

